import Game

def main():
    game = Game.Game()
    game.run()
    return
main()

